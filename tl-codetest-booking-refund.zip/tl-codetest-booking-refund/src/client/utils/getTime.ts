export function getTime(date: Date | string) {
    return new Date(date).getTime();
}